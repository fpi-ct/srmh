(function () {
  const origin = location.origin;
  const COURSE_PATH = "/GiangVien/Courses/Course.aspx";
  const GROUP_PATH = "/GiangVien/Courses/Groups.aspx";
  const REPORT_PATH = "/GiangVien/Attendance/SeeReport.aspx";
  const DELAY_MS = 150;
  let activeTermId = "28";
  let configCampus = "7";
  let configDept = "3";

  function getTermId() {
    return activeTermId;
  }

  function setTermId(id) {
    activeTermId = String(id);
  }

  function setConfig(cfg) {
    if (!cfg) return;
    if (cfg.term != null) setTermId(cfg.term);
    if (cfg.campus != null) configCampus = String(cfg.campus);
    if (cfg.dept != null) configDept = String(cfg.dept);
  }

  function getConfig() {
    return { term: getTermId(), campus: configCampus, dept: configDept };
  }

  function parseHtml(html) {
    return new DOMParser().parseFromString(html, "text/html");
  }

  function rows(doc, selector) {
    return [...doc.querySelectorAll(selector)];
  }

  function sleep(ms) {
    return new Promise((r) => setTimeout(r, ms));
  }

  async function getHtml(path) {
    const res = await fetch(`${origin}${path}`, { credentials: "include" });
    const html = await res.text();
    if (/\<title\>Login\<\/title\>/i.test(html)) {
      throw new Error(`Chưa đăng nhập: ${path}`);
    }
    return html;
  }

  function getSelectOptions(sel) {
    return [...sel.options]
      .map((o) => ({ value: o.value, text: o.textContent.replace(/\s+/g, " ").trim() }))
      .filter((o) => o.value && o.value !== "0");
  }

  function findSelect(doc, pattern) {
    return (
      doc.querySelector(`select[id*='${pattern}' i], select[name*='${pattern}' i]`) ||
      rows(doc, "select").find((s) => pattern.test(`${s.id} ${s.name}`))
    );
  }

  function parseFilterSelects(doc) {
    const campusSel = findSelect(doc, /campus|program/i) || rows(doc, "select")[0];
    const termSel = findSelect(doc, /listterm|term/i) || rows(doc, "select")[1];
    const deptSel = findSelect(doc, /dept|department/i) || rows(doc, "select")[2];

    const campus = campusSel ? getSelectOptions(campusSel) : [];
    const dept = deptSel ? getSelectOptions(deptSel) : [];

    let termName = "";
    if (termSel) {
      const termOpt = [...termSel.options].find((o) => o.value === getTermId());
      termName = termOpt?.textContent.replace(/\s+/g, " ").trim() || "";
    }

    return { campus, dept, termId: getTermId(), termName };
  }

  function buildFilterCombos(filters, urlParams) {
    const campus = filters.campus.length
      ? filters.campus
      : [{ value: urlParams.campus || configCampus, text: "" }];
    const dept = filters.dept.length
      ? filters.dept
      : [{ value: urlParams.dept || configDept, text: "" }];
    const term = { value: getTermId(), text: filters.termName || "" };
    const combos = [];

    for (const c of campus) {
      for (const d of dept) {
        combos.push({
          campus: c.value,
          term: term.value,
          dept: d.value,
          campusName: c.text,
          termName: term.text,
          deptName: d.text,
          url: `${COURSE_PATH}?campus=${c.value}&term=${term.value}&dept=${d.value}`
        });
      }
    }

    return combos;
  }

  function parseLecturersFromCell(cellText) {
    const m = cellText.match(/\(([A-Za-z0-9]+(?:;[A-Za-z0-9]+)*);\d{2}\/\d{2}\/\d{4}/);
    if (m) return m[1].split(";").filter(Boolean);
    const m2 = cellText.match(/\(([A-Za-z0-9]+(?:;[A-Za-z0-9]+)*)\)/);
    if (m2) return m2[1].split(";").filter((x) => !/^\d{2}\//.test(x));
    return [];
  }

  function parseCoursePage(doc, filterMeta) {
    const groups = new Map();
    const courses = [];

    rows(doc, "table tr").forEach((tr) => {
      const cells = [...tr.querySelectorAll("td")];
      if (cells.length < 3) return;

      const subject = cells[0]?.textContent?.replace(/\s+/g, " ").trim() || "";
      const courseDetail = cells[1]?.textContent?.replace(/\s+/g, " ").trim() || "";
      const studentCell = cells[2];
      const plan = cells[3]?.textContent?.replace(/\s+/g, " ").trim() || "";

      if (!studentCell) return;

      rows(studentCell, 'a[href*="Groups.aspx"]').forEach((a) => {
        try {
          const u = new URL(a.getAttribute("href"), origin);
          const groupId = u.searchParams.get("group");
          if (!groupId) return;

          const linkText = a.textContent.replace(/\s+/g, " ").trim();
          const m = linkText.match(/^([^\s(]+)\s*\(([^|]+)\s*\|\s*(\d+)\)/);
          const className = m?.[1] || linkText;
          const schedule = m?.[2]?.trim() || "";
          const enrolled = m?.[3] || "";

          const cellText = studentCell.textContent.replace(/\s+/g, " ");
          const lecturers = parseLecturersFromCell(cellText);

          const item = {
            groupId,
            subject,
            courseDetail,
            className,
            schedule,
            enrolled,
            plan,
            lecturers,
            lecturer: lecturers.join("; "),
            href: `${GROUP_PATH}?group=${groupId}`,
            ...filterMeta
          };

          groups.set(groupId, item);
          courses.push(item);
        } catch (_) {}
      });
    });

    rows(doc, 'a[href*="Groups.aspx"]').forEach((a) => {
      try {
        const groupId = new URL(a.getAttribute("href"), origin).searchParams.get("group");
        if (!groupId || groups.has(groupId)) return;
        const linkText = a.textContent.replace(/\s+/g, " ").trim();
        groups.set(groupId, {
          groupId,
          className: linkText,
          lecturers: [],
          lecturer: "",
          href: `${GROUP_PATH}?group=${groupId}`,
          ...filterMeta
        });
      } catch (_) {}
    });

    return { courses, groups: [...groups.values()] };
  }

  function getFilterIdsFromPage(doc) {
    const ids = { term: getTermId(), dept: "", course: "", group: "" };
    rows(doc, "select").forEach((sel) => {
      const val = sel.value;
      if (!val || val === "0") return;
      const blob = `${sel.id} ${sel.name}`.toLowerCase();
      if (/listterm|term/i.test(blob)) ids.term = val;
      else if (/dept|department/i.test(blob)) ids.dept = val;
      else if (/course/i.test(blob)) ids.course = val;
      else if (/group/i.test(blob)) ids.group = val;
    });
    return ids;
  }

  function extractSeeReportParams(doc, html, group) {
    const regex = /SeeReport\.aspx\?([^"'>\s]+)/gi;
    let m;
    while ((m = regex.exec(html)) !== null) {
      try {
        const u = new URL(`SeeReport.aspx?${m[1].replace(/&amp;/g, "&")}`, origin);
        return {
          term: u.searchParams.get("term") || getTermId(),
          dept: u.searchParams.get("dept") || group.dept || "",
          course: u.searchParams.get("course") || "",
          group: u.searchParams.get("group") || group.groupId
        };
      } catch (_) {}
    }
    const fromSelect = getFilterIdsFromPage(doc);
    return {
      term: fromSelect.term || getTermId(),
      dept: fromSelect.dept || group.dept || "",
      course: fromSelect.course || "",
      group: fromSelect.group || group.groupId
    };
  }

  function parseAttendanceReport(doc) {
    const tables = rows(doc, "table[id*='gv'], table").filter((t) => rows(t, "tr").length > 1);

    for (const table of tables) {
      const headerRow = table.querySelector("tr");
      const headers = [...headerRow.querySelectorAll("th,td")].map((c) =>
        c.textContent.replace(/\s+/g, " ").trim().toUpperCase()
      );

      const col = {
        code: headers.findIndex((h) => /CODE|ROLL|MSSV|MEMBER/.test(h)),
        name: headers.findIndex((h) => /NAME|SURNAME|STUDENT/.test(h)),
        absentRate: headers.findIndex((h) => /ABSENT.*%|ABS.*%|RATE|VẮNG|TỈ LỆ|PERCENT/.test(h)),
        absent: headers.findIndex((h) => /^ABSENT$|ABSENT\s*COUNT|VẮNG$/.test(h)),
        present: headers.findIndex((h) => /^PRESENT$|CÓ MẶT|ATTEND/.test(h)),
        total: headers.findIndex((h) => /TOTAL|TỔNG|SLOT|SESSION/.test(h))
      };

      if (col.code < 0 && col.absentRate < 0 && col.absent < 0) continue;

      const dataRows = rows(table, "tbody tr").length ? rows(table, "tbody tr") : rows(table, "tr").slice(1);
      const students = dataRows
        .map((tr) => {
          if (tr.querySelector("th")) return null;
          const cells = [...tr.querySelectorAll("td")];
          if (cells.length < 2) return null;
          const val = (idx) => (idx >= 0 && cells[idx] ? cells[idx].textContent.replace(/\s+/g, " ").trim() : "");

          const mssv = val(col.code) || val(0);
          if (!mssv || /^code|roll|no$/i.test(mssv)) return null;

          return {
            mssv,
            fullName: val(col.name),
            tyLeVang: val(col.absentRate),
            soBuoiVang: val(col.absent),
            soBuoiCoMat: val(col.present),
            tongBuoi: val(col.total)
          };
        })
        .filter(Boolean);

      if (students.length) return { students };
    }

    return { students: [] };
  }

  async function fetchAttendanceReport(group, groupDoc, groupHtml) {
    const params = extractSeeReportParams(groupDoc, groupHtml, group);
    if (!params.course || !params.group) return { params, students: [] };

    const q = new URLSearchParams({
      term: params.term,
      dept: params.dept,
      course: params.course,
      group: params.group
    });
    const html = await getHtml(`${REPORT_PATH}?${q}`);
    const parsed = parseAttendanceReport(parseHtml(html));
    return { params, students: parsed.students };
  }

  function mergeAttendance(students, reportStudents) {
    const map = new Map();
    reportStudents.forEach((r) => {
      const key = (r.mssv || "").replace(/\s/g, "").toUpperCase();
      if (key) map.set(key, r);
    });

    return students.map((s) => {
      const key = (s.mssv || s.roll || "").replace(/\s/g, "").toUpperCase();
      const r = map.get(key);
      if (!r) return s;
      return {
        ...s,
        tyLeVang: r.tyLeVang || "",
        soBuoiVang: r.soBuoiVang || "",
        soBuoiCoMat: r.soBuoiCoMat || "",
        tongBuoi: r.tongBuoi || ""
      };
    });
  }

  function getSelectedFilterText(doc) {
    const selected = {};
    rows(doc, "select").forEach((sel) => {
      const opt = sel.options[sel.selectedIndex];
      if (!opt) return;
      const blob = `${sel.id} ${sel.name}`.toLowerCase();
      if (/campus|program/i.test(blob)) selected.campusName = opt.textContent.trim();
      if (/term/i.test(blob)) selected.termName = opt.textContent.trim();
      if (/dept|department/i.test(blob)) selected.deptName = opt.textContent.trim();
      if (/group/i.test(blob)) selected.groupName = opt.textContent.trim();
      if (/course/i.test(blob)) selected.courseName = opt.textContent.trim();
    });
    return selected;
  }

  function parseGroupStudents(doc) {
    const filters = getSelectedFilterText(doc);
    const tables = rows(doc, "table").filter((t) => {
      const headers = [...t.querySelectorAll("tr:first-child th, tr:first-child td")].map((c) =>
        c.textContent.replace(/\s+/g, " ").trim().toUpperCase()
      );
      return headers.some((h) => h.includes("CODE")) && headers.some((h) => h.includes("SURNAME"));
    });

    const table = tables[0];
    if (!table) return { filters, students: [] };

    const headerRow = table.querySelector("tr");
    const headers = [...headerRow.querySelectorAll("th,td")].map((c) =>
      c.textContent.replace(/\s+/g, " ").trim().toUpperCase()
    );

    const col = {
      member: headers.findIndex((h) => h.includes("MEMBER")),
      code: headers.findIndex((h) => h === "CODE" || h.includes("CODE")),
      surname: headers.findIndex((h) => h.includes("SURNAME")),
      middle: headers.findIndex((h) => h.includes("MIDDLE")),
      given: headers.findIndex((h) => h.includes("GIVEN")),
      note: headers.findIndex((h) => h.includes("NOTE"))
    };

    const dataRows = rows(table, "tbody tr").length ? rows(table, "tbody tr") : rows(table, "tr").slice(1);

    const students = dataRows
      .map((tr, i) => {
        if (tr.querySelector("th")) return null;
        const cells = [...tr.querySelectorAll("td")];
        if (cells.length < 4) return null;

        const val = (idx) => (idx >= 0 && cells[idx] ? cells[idx].textContent.replace(/\s+/g, " ").trim() : "");

        const code = val(col.code);
        const surname = val(col.surname);
        const middleName = val(col.middle);
        const givenName = val(col.given);
        const fullName = [surname, middleName, givenName].filter(Boolean).join(" ");

        if (!code && !fullName) return null;

        return {
          index: i + 1,
          member: val(col.member),
          mssv: code,
          roll: code,
          surname,
          middleName,
          givenName,
          fullName,
          note: val(col.note)
        };
      })
      .filter(Boolean);

    return { filters, students };
  }

  async function fetchAllCourseGroups(onProgress) {
    const seedParams = new URL(location.href).searchParams;
    const urlParams = {
      campus: seedParams.get("campus") || "",
      term: seedParams.get("term") || "",
      dept: seedParams.get("dept") || ""
    };

    const seedCampus = urlParams.campus || configCampus;
    const seedDept = urlParams.dept || configDept;
    const seedHtml = await getHtml(
      `${COURSE_PATH}?campus=${seedCampus}&term=${getTermId()}&dept=${seedDept}`
    );
    const seedDoc = parseHtml(seedHtml);
    const filters = parseFilterSelects(seedDoc);
    const combos = buildFilterCombos(filters, urlParams);

    const groupMap = new Map();
    const allCourses = [];

    for (let i = 0; i < combos.length; i++) {
      const combo = combos[i];
      const html = await getHtml(combo.url);
      const doc = parseHtml(html);
      const parsed = parseCoursePage(doc, {
        campus: combo.campus,
        term: combo.term,
        dept: combo.dept,
        campusName: combo.campusName,
        termName: combo.termName,
        deptName: combo.deptName
      });

      parsed.groups.forEach((g) => groupMap.set(g.groupId, { ...groupMap.get(g.groupId), ...g }));
      allCourses.push(...parsed.courses);

      if (onProgress) {
        onProgress({
          type: "course-filter",
          current: i + 1,
          total: combos.length,
          groupCount: groupMap.size,
          filter: combo
        });
      }

      await sleep(DELAY_MS);
    }

    return {
      filters,
      combos,
      courses: allCourses,
      groups: [...groupMap.values()]
    };
  }

  async function fetchGroupDetail(group, onProgress) {
    const html = await getHtml(`${GROUP_PATH}?group=${group.groupId}`);
    const doc = parseHtml(html);
    const { filters, students } = parseGroupStudents(doc);

    let mergedStudents = students;
    try {
      const report = await fetchAttendanceReport(group, doc, html);
      mergedStudents = mergeAttendance(students, report.students);
      group.reportParams = report.params;
    } catch (_) {}

    if (onProgress) {
      onProgress({
        type: "group",
        groupId: group.groupId,
        className: group.className,
        studentCount: mergedStudents.length
      });
    }

    return {
      ...group,
      groupName: filters.groupName || group.className,
      termName: filters.termName || group.termName,
      deptName: filters.deptName || group.deptName,
      courseName: filters.courseName || group.courseDetail,
      lecturers: group.lecturers?.length ? group.lecturers : [],
      lecturer: group.lecturer || "",
      students: mergedStudents.map((s) => ({
        ...s,
        className: filters.groupName || group.className,
        groupId: group.groupId,
        lecturer: group.lecturer || "",
        subject: group.subject || "",
        courseDetail: group.courseDetail || "",
        deptName: group.deptName || filters.deptName || "",
        termName: group.termName || filters.termName || ""
      }))
    };
  }

  async function fetchAll(onProgress) {
    if (onProgress) onProgress({ type: "start", message: "Crawl Course.aspx..." });

    const courseData = await fetchAllCourseGroups(onProgress);
    const classStudents = [];
    const allStudents = [];
    const lecturerSet = new Set();

    courseData.groups.forEach((g) => {
      (g.lecturers || []).forEach((l) => lecturerSet.add(l));
      if (g.lecturer) g.lecturer.split(";").forEach((l) => lecturerSet.add(l.trim()));
    });

    for (let i = 0; i < courseData.groups.length; i++) {
      const group = courseData.groups[i];
      try {
        const detail = await fetchGroupDetail(group, onProgress);
        classStudents.push(detail);
        allStudents.push(...detail.students);
      } catch (err) {
        classStudents.push({ ...group, error: err.message, students: [] });
      }

      if (onProgress) {
        onProgress({
          type: "progress",
          current: i + 1,
          total: courseData.groups.length,
          studentCount: allStudents.length
        });
      }

      await sleep(DELAY_MS);
    }

    return {
      fetchedAt: new Date().toISOString(),
      origin,
      mode: "giangvien-courses",
      courses: courseData.courses,
      groups: courseData.groups,
      classStudents,
      students: allStudents,
      lecturers: [...lecturerSet].filter(Boolean),
      stats: {
        filterCombos: courseData.combos.length,
        courseRows: courseData.courses.length,
        groupCount: courseData.groups.length,
        classWithStudents: classStudents.filter((c) => c.students?.length).length,
        studentCount: allStudents.length,
        lecturerCount: lecturerSet.size
      }
    };
  }

  async function getTermOptions() {
    const seedParams = new URL(location.href).searchParams;
    const campus = seedParams.get("campus") || configCampus;
    const dept = seedParams.get("dept") || configDept;
    const html = await getHtml(`${COURSE_PATH}?campus=${campus}&term=${getTermId()}&dept=${dept}`);
    const termSel = findSelect(parseHtml(html), /listterm|term/i);
    if (!termSel) return [];
    return getSelectOptions(termSel);
  }

  function csvEscape(value) {
    const s = String(value ?? "");
    if (/[",\n\r]/.test(s)) return `"${s.replace(/"/g, '""')}"`;
    return s;
  }

  function toCsv(columns, rows) {
    const header = columns.map((c) => csvEscape(c.label)).join(",");
    const lines = rows.map((row) => columns.map((c) => csvEscape(c.get(row))).join(","));
    return "\uFEFF" + [header, ...lines].join("\r\n");
  }

  function buildCombinedRows(data) {
    const rows = [];

    (data.classStudents || []).forEach((cls) => {
      const base = {
        groupId: cls.groupId || "",
        lop: cls.className || cls.groupName || "",
        mon: cls.subject || "",
        monChiTiet: cls.courseDetail || cls.courseName || "",
        gv: cls.lecturer || "",
        khoa: cls.deptName || "",
        hocKy: cls.termName || ""
      };

      if (!cls.students?.length) {
        rows.push({ ...base, mssv: "", hoTen: "", member: "", ghiChu: "", tyLeVang: "" });
        return;
      }

      cls.students.forEach((s) => {
        rows.push({
          ...base,
          mssv: s.mssv || s.roll || "",
          hoTen: s.fullName || "",
          member: s.member || "",
          ghiChu: s.note || "",
          tyLeVang: s.tyLeVang || ""
        });
      });
    });

    return rows;
  }

  function toCombinedCsv(data) {
    const columns = [
      { label: "MSSV", get: (r) => r.mssv },
      { label: "HoTen", get: (r) => r.hoTen },
      { label: "Member", get: (r) => r.member },
      { label: "GhiChu", get: (r) => r.ghiChu },
      { label: "TyLeVang", get: (r) => r.tyLeVang },
      { label: "Lop", get: (r) => r.lop },
      { label: "GroupId", get: (r) => r.groupId },
      { label: "Mon", get: (r) => r.mon },
      { label: "MonChiTiet", get: (r) => r.monChiTiet },
      { label: "GV", get: (r) => r.gv },
      { label: "Khoa", get: (r) => r.khoa },
      { label: "HocKy", get: (r) => r.hocKy }
    ];
    return toCsv(columns, buildCombinedRows(data));
  }

  async function fetchAndExport(termId) {
    if (termId) setTermId(termId);
    const data = await fetchAll();
    return {
      data,
      csv: toCombinedCsv(data)
    };
  }

  window.FAPFetch = {
    origin,
    getTermId,
    setTermId,
    setConfig,
    getConfig,
    getTermOptions,
    parseCoursePage,
    parseGroupStudents,
    fetchAllCourseGroups,
    fetchGroupDetail,
    fetchAll,
    toCombinedCsv,
    fetchAndExport
  };
})();
