const termEl = document.getElementById("term");
const exportBtn = document.getElementById("exportBtn");
const reloadBtn = document.getElementById("reloadTerms");
const statusEl = document.getElementById("status");

let appConfig = { term: "28", campus: "7", dept: "3" };

async function loadAppConfig() {
  try {
    const url = chrome.runtime.getURL("config.json");
    const res = await fetch(url);
    if (res.ok) {
      const raw = await res.json();
      appConfig = {
        term: String(raw.term ?? appConfig.term),
        campus: String(raw.campus ?? appConfig.campus),
        dept: String(raw.dept ?? appConfig.dept)
      };
    }
  } catch {
  }
}

function setStatus(text, type) {
  statusEl.textContent = text;
  statusEl.className = `status${type ? ` ${type}` : ""}`;
}

async function getFapTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id || !tab.url?.includes("fap.fpi.edu.vn")) {
    throw new Error("Mở tab fap.fpi.edu.vn đã đăng nhập");
  }
  return tab;
}

async function runInPage(func, args = []) {
  const tab = await getFapTab();
  const [result] = await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    world: "MAIN",
    func,
    args
  });
  return result.result;
}

function fillTerms(terms, savedTermId) {
  termEl.innerHTML = "";
  if (!terms?.length) {
    termEl.innerHTML = '<option value="">Không tải được học kỳ</option>';
    return;
  }
  terms.forEach((t) => {
    const opt = document.createElement("option");
    opt.value = t.value;
    opt.textContent = t.text || `Term ${t.value}`;
    termEl.appendChild(opt);
  });
  const selected = savedTermId || appConfig.term;
  const has = [...termEl.options].some((o) => o.value === selected);
  termEl.value = has ? selected : termEl.options[0].value;
}

async function loadTerms() {
  setStatus("Đang tải học kỳ...");
  reloadBtn.disabled = true;
  try {
    const saved = await chrome.storage.local.get(["termId"]);
    const terms = await runInPage(async (cfg) => {
      if (!window.FAPFetch) throw new Error("Reload trang FAP");
      window.FAPFetch.setConfig(cfg);
      return window.FAPFetch.getTermOptions();
    }, [appConfig]);
    fillTerms(terms, saved.termId);
    setStatus(`Đã tải ${terms.length} học kỳ`);
  } catch (err) {
    fillTerms([], "");
    setStatus(err.message, "error");
  } finally {
    reloadBtn.disabled = false;
  }
}

function downloadCsv(filename, content) {
  const blob = new Blob([content], { type: "text/csv;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

async function exportCsv() {
  const termId = termEl.value;
  if (!termId) {
    setStatus("Chọn học kỳ", "error");
    return;
  }

  exportBtn.disabled = true;
  reloadBtn.disabled = true;
  setStatus("Đang crawl dữ liệu, chờ vài phút...");

  try {
    await chrome.storage.local.set({ termId });

    const result = await runInPage(async (selectedTermId, cfg) => {
      if (!window.FAPFetch) throw new Error("Reload trang FAP");
      window.FAPFetch.setConfig({ ...cfg, term: selectedTermId });
      return window.FAPFetch.fetchAndExport(selectedTermId);
    }, [termId, appConfig]);

    const termLabel = [...termEl.options].find((o) => o.value === termId)?.textContent?.trim() || termId;
    const safeTerm = termLabel.replace(/[^\w.-]+/g, "_");
    const stamp = new Date().toISOString().slice(0, 10);
    downloadCsv(`fap-export_${safeTerm}_${stamp}.csv`, result.csv);

    const s = result.data.stats;
    setStatus(
      `Xong: ${s.studentCount} SV, ${s.groupCount} lớp, ${s.lecturerCount} GV`,
      "ok"
    );
  } catch (err) {
    setStatus(err.message || String(err), "error");
  } finally {
    exportBtn.disabled = false;
    reloadBtn.disabled = false;
  }
}

reloadBtn.addEventListener("click", loadTerms);
exportBtn.addEventListener("click", exportCsv);
loadAppConfig().then(loadTerms);
